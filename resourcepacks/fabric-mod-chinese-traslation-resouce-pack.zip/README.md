# fabric-mod-chinese-traslation-resouce-pack

Making traslate for mod<br>

###### 目前zh_tw有翻譯有

* Advanced NBT Tooltips
* appleskin
* authme
* auto reconnect
* betterf3
* bettersodiumbutton
* breakprogress
* chest tracker
* clientcommands
* easierchests
* easiervillagertrading
* enhanced attack indicator
* entityyoutliner
* foodui
* fuelinfo
* ingameime
* itemscroller
* lightoverlay
* litematica
* malilib
* masa gadge
* minihud
* modmenu
* ommc
* petowner
* sodium extra
* timetolive
* tweakeroo + tweakfork
* waila
* xaeroworldmap
* xaerominimap  

註:請全部用UTF8  
簡體翻譯來源 : <https://www.bilibili.com/read/cv6583563><br>

#### forge mod請去 <https://github.com/whats2000/mod-pack-traditional-chinese-traslation>  

註:如果下載自code的自動壓縮檔，需要解壓縮一次

# fabric-mod-chinese-traslation-resouce-pack

Making traslate for mod

###### 目前zh_cn有翻译有

* foodui
* itemscroller
* litematica
* malilib
* minihud
* tweakeroo + tweakfork  

注:请全部用UTF8  
简体翻译来源 : <https://www.bilibili.com/read/cv6583563>

#### forge mod請去 <https://github.com/whats2000/mod-pack-traditional-chinese-traslation>  

注:如果下载自code的自动压缩档，需要解压缩一次
